import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

function BlogPost() {
  const { id } = useParams();
  const [blogPost, setBlogPost] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:5000/posts/${id}`)
      .then(res => {
        setBlogPost(res.data);
      })
      .catch(err => console.log(err));
  }, [id]);

  return (
    <div>
      <h1>{blogPost.title}</h1>
      <p>{blogPost.content}</p>
      <p>Author: {blogPost.author}</p>
      <Link to={`/update/${id}`}>Edit Post</Link>
    </div>
  );
}

export default BlogPost;
