
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';


const Bloglist = () => {

  const [blogPosts, setBlogPosts] = useState([]);
  const [deleteTrue, setDeleteTrue] = useState(false)

  const getBlogList = async()=>{
    try{
    const result = await axios.get('http://localhost:2122/all-blogs');
    console.log("result>>>",result)
    setBlogPosts(result.data.data);
    }catch(error){
      console.log("error>>>",error)
    }

  }

  useEffect(() => {
    getBlogList()
  }, []);
  
  useEffect(() => {
    if(deleteTrue){
    getBlogList()
    }
  }, [deleteTrue]);

  
  const handleDelete = async (id) => {
    try { // Send a POST request to delete the blog post
     const result = await axios.post("http://localhost:2122/delete-blog", { _id: id });
      console.log("delete>>>", result);
      alert("delete successfully"); // Display a success message
      setDeleteTrue(true); // Trigger a refresh of the blog posts
    } catch (error) { // If an error occurs, display an error message and reset deleteTrue
      console.log("error");
      alert("something went wrong!");
      setDeleteTrue(false);
    }
  };


  return (
    <>
       <div className="blog-list">
      <h1>Blog Posts</h1>
      {blogPosts.length <= 0 ?
      <p>No blog post created yet</p>
      :
      <ul>
        {blogPosts && blogPosts.map(post => (
          <li key={post._id}>
            <div>
              <h2>{post.title}</h2>
              <p>{post.content}</p>
              <p>Author: {post.author}</p>
              <Link to={`/post/${post._id}`}>View</Link>
              <Link to={`/edit-blog/${post._id}`}>Update</Link>
              <button type="button" onClick={()=>handleDelete(post._id)} >Delete</button>
            </div>
          </li>
        ))}
      </ul>
       }
      <Link to="/create">Create New Post</Link>
    </div>
    </>
  )
}

export default Bloglist
