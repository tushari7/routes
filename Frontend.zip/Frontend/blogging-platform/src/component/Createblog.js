import React,{useState} from 'react';
import axios from 'axios';
import '../component/style.css';
import { useNavigate } from 'react-router-dom';

const Createblog = () => {

  const navigate = useNavigate("")
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [author, setAuthor] = useState('');

  const handleSubmit = async(e) => {
    e.preventDefault();

    const newPost = {
      title :title,
      content : content,
      author: author
    };
    console.log("newpost>>>",newPost)
    try {
      const result =  await axios.post('http://localhost:2122/create-blogs', newPost)
      console.log("result>>>",result)
      navigate('/bloglist')
      
    } catch (error) {
      console.log("error>>>>",error)
      alert("something went wrong !")
    }
   

    setTitle('');
    setContent('');
    setAuthor('');
  };
  return (
    <>
        <div className="create-blog-form">
      <h2>Add New Blog Post</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">Title:</label>
          <input type="text" id="title" placeholder="Add Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div className="form-group">
          <label htmlFor="content">Content:</label>
          <textarea id="content" placeholder="Add Content" value={content} onChange={(e) => setContent(e.target.value)}></textarea>
        </div>
        <div className="form-group">
          <label htmlFor="author">Author:</label>
          <input type="text" id="author" placeholder="Add Author" value={author} onChange={(e) => setAuthor(e.target.value)} />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
    </>
  )
}

export default Createblog


