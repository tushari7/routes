
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';


const Updateblog = () => {
  const { id } = useParams();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [author, setAuthor] = useState('');

  useEffect(() => {

    const getBlog = async()=>{
      try {
        const result = await axios.get(`http://localhost:2122/posts/${id}`);
        console.log("result>>>",result)    
      } catch (error) {
        console.log("eror>>>",error)
      }
    }
    getBlog()
  }, [id]);

  const handleSubmit = async(e) => {
    e.preventDefault();

    const updatedPost = {
      _id:id,
      title:title,
      content: content,
      author: author
    };
    console.log("updatepost>>>",updatedPost)
try {
  const result = await axios.post("http://localhost:2122/update-blogs",updatedPost)
  console.log("result>>>>",result)
} catch (error) {
  console.log("error>>>",error)
}
  };






  return (
    <>
      <div className="create-blog-form">
      <h2>Update Blog Post</h2>
      <form>
        <div className="form-group">
          <label htmlFor="title">Title:</label>
          <input type="text" id="title" placeholder="Add Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div className="form-group">
          <label htmlFor="content">Content:</label>
          <textarea id="content" placeholder="Add Content" value={content} onChange={(e) => setContent(e.target.value)}></textarea>
        </div>
        <div className="form-group">
          <label htmlFor="author">Author:</label>
          <input type="text" id="author" placeholder="Add Author" value={author} onChange={(e) => setAuthor(e.target.value)} />
        </div>
        <button type="submit" onClick={handleSubmit}>Update</button>
      </form>
    </div>
    </>
  )
}

export default Updateblog

