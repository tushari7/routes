import './App.css';
import { Routes, Route,} from "react-router-dom";
import { Navigate } from 'react-router-dom';
import Createblog from './component/Createblog';
import Updateblog from './component/Updateblog';
import Bloglist from './component/BlogPage';


function App() {
  return (
    <div>
<Routes>
<Route exact path='/' element = {<Navigate to ="/bloglist"/>} /> 
<Route  path='/bloglist' element = {<Bloglist/>} />
<Route  path='/create' element = {<Createblog/>} />
<Route  path='/edit-blog/:id' element = {<Updateblog/>} />
<Route/>

</Routes>
      
    </div>
  );
}

export default App;
